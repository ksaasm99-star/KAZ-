package com.kaz.generated.kaze2etodo1793327776335

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            text = "إنشاء تطبيق Todo عربي بسيط لإدارة المهام"
            textSize = 20f
        })
    }
}
