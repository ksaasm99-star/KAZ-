plugins {
    id("com.android.application")
}

android {
    namespace = "com.kaz.generated.kaze2etodo1793327776335"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.kaz.generated.kaze2etodo1793327776335"
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
